package com.alejomendez.java.actividad2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlejomendezActividad2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
