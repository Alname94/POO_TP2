package com.alejomendez.java.actividad2.entidades;

public class Auto extends Vehiculo {
    //se declara final ya que al ser una concesionaria, no se modificará la cantidad de puertas de un auto. 
    private final Integer CANTIDADPUERTAS;

    public Auto(String MARCA, String MODELO, Double PRECIO, Integer CANTIDADPUERTAS) {
        super(MARCA, MODELO, PRECIO);
        this.CANTIDADPUERTAS = CANTIDADPUERTAS;        
    }

    //sobreescritura del método toString() para mostrar la marca, modelo, cantidad de puertas y el precio con el formato deseado.
    @Override
    public String toString() {
        return "Marca: " + this.getMARCA() + " // Modelo: " + this.getMODELO() + " // Puertas: " + CANTIDADPUERTAS + " // Precio: " + formatearPrecio(); 
    }

    //sobreescritura del método compareTo para poder establecer un orden natural de los objetos
    @Override
    public int compareTo(Vehiculo autoParam) {
        String thisAuto = this.getMARCA() + "," + this.getMODELO() + "," + this.getPrecio();
        String ParamAuto = autoParam.getMARCA() + "," + autoParam.getMODELO() + "," + autoParam.getPrecio();
        return thisAuto.compareTo(ParamAuto);
    }    

}
