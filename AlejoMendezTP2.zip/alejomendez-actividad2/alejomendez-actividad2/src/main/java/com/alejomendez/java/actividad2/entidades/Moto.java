package com.alejomendez.java.actividad2.entidades;

import lombok.Getter;

@Getter
public class Moto extends Vehiculo {
    //se declara final ya que al ser una concesionaria, no se modificará la cilindrada de las motos.
    private final Integer CILINDRADA;
    
    public Moto(String MARCA, String MODELO, Double PRECIO, Integer CILINDRADA) {
        super(MARCA, MODELO, PRECIO);
        this.CILINDRADA = CILINDRADA;
    }

    //sobreescritura del método toString() para mostrar la marca, modelo, cilindrada y el precio con el formato deseado.
    @Override
    public String toString() {
        return "Marca: " + this.getMARCA() + " // Modelo: " + this.getMODELO() + " // Cilindrada: " + CILINDRADA + "c" + " // Precio: " + formatearPrecio(); 
    }

    @Override
    public int compareTo(Vehiculo motoParam) {
        String thisMoto = this.getMARCA() + "," + this.getMODELO() + "," + this.getPrecio();
        String ParamMoto = motoParam.getMARCA() + "," + motoParam.getMODELO() + "," + motoParam.getPrecio();
        return thisMoto.compareTo(ParamMoto);
    }
    
}
