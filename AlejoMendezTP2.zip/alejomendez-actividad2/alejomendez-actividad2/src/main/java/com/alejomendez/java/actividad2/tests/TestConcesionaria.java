package com.alejomendez.java.actividad2.tests;

import java.util.ArrayList;
import java.util.List;

import com.alejomendez.java.actividad2.entidades.Auto;
import com.alejomendez.java.actividad2.entidades.Moto;
import com.alejomendez.java.actividad2.entidades.Vehiculo;

public class TestConcesionaria {
    public static void main(String[] args) {

        //creamos una lista con Vehículo como Generic y añadimos autos y motos.
        //ya que solo es una versión de ejemplo y se prioriza el recorrido de elementos, se optó por una ArrayList.
        List<Vehiculo> listaVehiculos = new ArrayList<>();
        listaVehiculos.add(new Auto("Peugeot", "206", 200000.00, 4));
        listaVehiculos.add(new Moto("Honda", "Titan", 60000.00, 125));
        listaVehiculos.add(new Auto("Peugeot", "208", 250000.00, 5));
        listaVehiculos.add(new Moto("Yamaha", "YBR", 80500.50, 160));
        
        //Vehículos por orden de inserción
        listaVehiculos.forEach(System.out::println);
        
        System.out.println("\n========================================\n");
        
        // //Vehiculo más caro
        Vehiculo.informarVehiculoMasCaro(listaVehiculos);
        //Vehículo más barato                     
        Vehiculo.informarVehiculoMasBarato(listaVehiculos);
        //Vehículo por letra en el modelo
        Vehiculo.buscarModeloPorLetra(listaVehiculos, "y");

        System.out.println("\n========================================\n");

        //Vehículos ordenados por precio de mayor a menor:
        Vehiculo.ordenarMayorMenor(listaVehiculos);

        System.out.println("\n========================================\n");

        //Vehículos ordenados por orden natural (marca, modelo, precio):
        Vehiculo.ordenarNaturalmente(listaVehiculos);
    }
}
