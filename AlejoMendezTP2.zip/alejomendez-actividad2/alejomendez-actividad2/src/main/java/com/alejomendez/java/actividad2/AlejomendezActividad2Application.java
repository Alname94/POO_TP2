package com.alejomendez.java.actividad2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlejomendezActividad2Application {

	public static void main(String[] args) {
		SpringApplication.run(AlejomendezActividad2Application.class, args);
	}

}
