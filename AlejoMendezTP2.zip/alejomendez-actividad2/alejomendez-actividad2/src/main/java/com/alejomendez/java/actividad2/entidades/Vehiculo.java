package com.alejomendez.java.actividad2.entidades;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true) //lo implementamos para poder omitir duplicados de vehículos con misma marca y modelo
//la clase abstracta Vehiculo permite que las clases Auto y Moto hereden sus atributos, métodos e interfaz Comparable. 
public abstract class Vehiculo implements Comparable<Vehiculo> {
    @EqualsAndHashCode.Include
    private final String MARCA;
    @EqualsAndHashCode.Include    
    private final String MODELO;
    private double precio;

    public static List<Vehiculo> crearListaVehiculos(){
        List<Vehiculo> listaVehiculos = new ArrayList<>();
        listaVehiculos.add(new Auto("Peugeot", "206", 200000.00, 4));
        listaVehiculos.add(new Moto("Honda", "Titan", 60000.00, 125));
        listaVehiculos.add(new Auto("Peugeot", "208", 250000.00, 5));
        listaVehiculos.add(new Moto("Yamaha", "YBR", 80500.50, 160));
        return listaVehiculos;
    }

    //Este método será utilizado en los constructores de Auto y Moto para mostrar el precio con el formato deseado.
    public String formatearPrecio(){
        DecimalFormat precioFormateado = new DecimalFormat("$###,###.00");
        return precioFormateado.format(this.getPrecio());
    }

    //Estas dos funciones nos permiten obtener el precio máximo y mínimo de una lista de Vehículos
    //Ambas son utilizadas por los métodos que informan a qué vehículo corresponde dicho precio.
    public double obtenerPrecioMaximo(List<Vehiculo> lista){
        double precioMaximo=
                            lista
                                .stream()
                                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
        return precioMaximo;                                  
    }

    public double obtenerPrecioMinimo(List<Vehiculo> lista){
        double precioMinimo=
                            lista
                                .stream()
                                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                                .get()
                                .getPrecio();
        return precioMinimo;                                  
    }

    /**
     * Este método nos permite informar por pantalla, la marca y el modelo del vehículo con el precio más caro, dentro de la lista seleccionada como parámetro.
     * Ya que solo informamos la marca y el modelo, en caso de que haya más de un vehículo con misma marca y modelo, se omitirán los duplicados.
     * (Podrían agregarse más datos del vehículo).
     * @param lista
     */
    public static void informarVehiculoMasCaro(List<Vehiculo> lista){
        lista
            .stream()
            .filter(v->v.getPrecio() == v.obtenerPrecioMaximo(lista))
            .distinct()
            .forEach(item -> System.out.println("Vehiculo más caro: " + item.getMARCA() + " " + item.getMODELO()));
    }

    /**
     * Este método nos permite informar por pantalla, la marca y el modelo del vehículo con el precio más barato, dentro de la lista seleccionada como parámetro.
     * Ya que solo informamos la marca y el modelo, en caso de que haya más de un vehículo con misma marca y modelo, se omitirán los duplicados con .distinct().
     * (Podrían agregarse más datos del vehículo).
     * @param lista
     */
    public static void informarVehiculoMasBarato(List<Vehiculo> lista){
        lista
            .stream()
            .filter(v->v.getPrecio() == v.obtenerPrecioMinimo(lista))
            .distinct()
            .forEach(item -> System.out.println("Vehiculo más barato: " + item.getMARCA() + " " + item.getMODELO()));
    }

    /**
     * Este método nos permite obtener y mostrar por pantalla la marca, el modelo y el precio de un vehículo, filtrando por la del modelo del mismo.
     * Debe pasarse como parámetro la lista de Vehículos y la letra del modelo a buscar.
     * @param lista
     * @param letra
     */
    public static void buscarModeloPorLetra(List<Vehiculo> lista, String letra){
        lista
            .stream()
            .filter(v->v.getMODELO().toLowerCase().contains(letra))
            .forEach(item -> System.out.println("Vehiculo que contiene en el modelo la letra '" + letra.toUpperCase() + "': " + item.getMARCA() + " " + item.getMODELO() + " " + item.formatearPrecio()));
    }

    /**
     * Este método compara los precios de cada vehículo dentro de la lista pasada como parámetro, obtiene la marca y el modelo de cada uno y los muestra por pantalla, ordenados de mayor a menor.
     * Ya que solo informamos la marca y el modelo, en caso de que haya más de un vehículo con misma marca y modelo, se omitirán los duplicados con .distinct().
     * @param lista
     */
    public static void ordenarMayorMenor(List<Vehiculo> lista){
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        lista
            .stream()
            .distinct()
            .sorted(Comparator.comparing(Vehiculo::getPrecio)
            .reversed())
            .forEach(item -> System.out.println(item.getMARCA() + " " + item.getMODELO()));
    }

    /**
     * Este método muestra por pantalla la lista de vehículos ordenados por orden natural.
     * Utiliza la clase Collections con el método .sort(), el cual permite el ordenamiento natural de los objetos de las clases que implementen la interfaz Comparable.
     * Debe pasarse como parámetro la lista de Vehículos.
     * @param lista
     */
    public static void ordenarNaturalmente(List<Vehiculo> lista){
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        Collections.sort(lista);
        lista.forEach(System.out::println);
    }

}
